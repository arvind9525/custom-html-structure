$(document).ready(function(){
    $('.menuIcon').click(function(){
        $('.leftSideMenu').addClass('showLeftMenu');
       })

       $('.closeIcon').click(function(){
        $('.leftSideMenu').removeClass('showLeftMenu');
       })
  });